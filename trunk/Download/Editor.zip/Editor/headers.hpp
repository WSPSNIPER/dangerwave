#include<iostream>
#include<fstream>
#include<string>
#include<cstdlib>
#include<vector>

#include<SFML/System.hpp>
#include<SFML/Graphics.hpp>
#include<SFML/Window.hpp>

using namespace std;


